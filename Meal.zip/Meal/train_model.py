import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
import pickle
df = pd.read_csv("datasets/Final Data set.csv")
print(df.head())
# Drop rows with any missing values (optional but safe)
df = df.dropna()

# Define features (X) and target (y)
X = df.drop("Daily_Calories", axis=1)
y = df["Daily_Calories"]

# One-hot encode categorical columns
X = pd.get_dummies(X)
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
import pickle

# Split into training and testing data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create and train the Random Forest model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Optional: check model accuracy
print("Training complete! Accuracy on test set:", model.score(X_test, y_test))

# Save the model to file
with open("model/random_forest_model.pkl", "wb") as f:
    pickle.dump(model, f)
