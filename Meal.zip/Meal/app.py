import pickle
import pandas as pd
import numpy as np
import sqlite3
import datetime



from flask import Flask, render_template, request,redirect, url_for, session, flash
# Load the meal suggestion dataset
meal_df = pd.read_excel("datasets/Meal suggestions.xlsx")


app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Required for flash messages and sessions

with open("model/random_forest_model.pkl", "rb") as f:
    model = pickle.load(f)
    # Load nutrient data
nutrient_df = pd.read_csv("datasets/Micro and macro nutrients.csv")

print("Meals loaded:", meal_df.shape)
print(meal_df.head())


@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Basic form inputs
    age = int(request.form['age'])
    if age < 12 or age > 90:
      return "Age must be between 12 and 90."
    gender = request.form['gender']
    weight = int(request.form['weight'])
    if weight < 20 or weight > 140:
      return "Weight must be between 20 and 140 kg."
    height = int(request.form['height'])
    if height < 100 or height > 230:
      return "Height must be between 100 and 230 cm."
    diet = request.form['diet']
    activity = request.form['activity']
    health_goal = request.form['goal']

    # Multiple selections from form
    diseases = request.form.getlist('disease')   # ⬅️ handles multi-select
    allergies = request.form.getlist('allergy')  # ⬅️ handles multi-select

    # Start input dictionary
    input_data = {
        'Age': age,
        'Weight_kg': weight,
        'Height_cm': height,
        'Gender_' + gender: 1,
        'Diet_Preference_' + diet: 1,
        'Activity_Level_' + activity: 1,
        'Health_Goal_' + health_goal: 1,
    }

    # Add all selected diseases and allergies (mark them as 1)
    for d in diseases:
        input_data['Disease_' + d] = 1
    for a in allergies:
        input_data['Food_Allergies_' + a] = 1

    # Prepare input for model
    input_df = pd.DataFrame([input_data])
    model_features = model.feature_names_in_ if hasattr(model, 'feature_names_in_') else input_df.columns
    full_input = pd.DataFrame(np.zeros((1, len(model_features))), columns=model_features)
    full_input.update(input_df)

    # Predict calories
    predicted_calories = model.predict(full_input)[0]
    rounded_calories = int(round(predicted_calories, -1))

# Load user input
    user_diet = request.form['diet']
    user_allergies = request.form.getlist('allergy')

# FILTER MEALS ONLY by diet and allergy
    filtered_meals = meal_df[meal_df['Diet_Type'] == user_diet]

# Remove any dishes with the user's allergens
    for allergy in user_allergies:
     if allergy != "None":
        filtered_meals = filtered_meals[~filtered_meals['Allergens'].str.contains(allergy, case=False, na=False)]

# Separate filtered meals by type
    breakfasts = filtered_meals[filtered_meals['Meal_Type'] == 'Breakfast']
    lunches = filtered_meals[filtered_meals['Meal_Type'] == 'Lunch']
    dinners = filtered_meals[filtered_meals['Meal_Type'] == 'Dinner']

    print("🟢 Filtered Breakfasts:", breakfasts.shape)
    print("🟢 Filtered Lunches:", lunches.shape)
    print("🟢 Filtered Dinners:", dinners.shape)
    print("✅ Allergies selected:", user_allergies)
    print("✅ Diet selected:", user_diet)

# Safe sample function — returns Dish + Calories
    def safe_sample(meals_df, count=7):
        try:
            if meals_df.empty:
                return [{'Dish_Name': '-', 'Estimated_Calories': '-'}] * count
            sampled = meals_df.sample(n=min(count, len(meals_df)))
            return sampled[['Dish_Name', 'Estimated_Calories']].to_dict(orient='records')
        except Exception as e:
         print("safe_sample error:", e)
         return [{'Dish_Name': 'Error', 'Estimated_Calories': 'N/A'}] * 7

# Final Weekly Plan with calorie values included
    weekly_plan = {
    'Breakfast': safe_sample(breakfasts, 7),
    'Lunch': safe_sample(lunches, 7),
    'Dinner': safe_sample(dinners, 7)
}


    print("Sample Weekly Plan Breakfast:", weekly_plan['Breakfast'])
    if 'user_id' in session:
        user_id = session['user_id']
        today = datetime.date.today().isoformat()

    # Combine all meals into strings
        breakfast_str = ', '.join([meal['Dish_Name'] for meal in weekly_plan['Breakfast']])
        lunch_str = ', '.join([meal['Dish_Name'] for meal in weekly_plan['Lunch']])
        dinner_str = ', '.join([meal['Dish_Name'] for meal in weekly_plan['Dinner']])

        conn = sqlite3.connect('meal_app.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO meal_plans (user_id, date, breakfast, lunch, dinner) VALUES (?, ?, ?, ?, ?)",
                   (user_id, today, breakfast_str, lunch_str, dinner_str))
        conn.commit()
        conn.close()


# Find closest matching row in nutrient dataset
    closest_row = nutrient_df.iloc[(nutrient_df['Daily_Calories'] - rounded_calories).abs().argmin()]
    nutrients = {
    'Protein (g)': closest_row['Protein_g'],
    'Carbohydrates (g)': closest_row['Carbs_g'],
    'Fats (g)': closest_row['Fat_g'],
    'Fiber (g)': closest_row['Fiber_g'],
    'Sugar (g)': closest_row['Sugar_g'],
    'Vitamin A (mcg)': closest_row['Vitamin_A_mcg'],
    'Vitamin C (mg)': closest_row['Vitamin_C_mg'],
    'Vitamin D (mcg)': closest_row['Vitamin_D_mcg'],
    'Calcium (mg)': closest_row['Calcium_mg'],
    'Iron (mg)': closest_row['Iron_mg']
}


    return render_template('result.html', calories=round(predicted_calories), nutrients=nutrients, meal_plan=weekly_plan)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/developer')
def developer():
    return render_template('developer.html')

# Other app routes above...

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = sqlite3.connect('meal_app.db')
        cursor = conn.cursor()

        try:
            cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            conn.commit()
            conn.close()
            flash('Registration successful. Please login.', 'success')
            return redirect('/login')
        except sqlite3.IntegrityError:
            flash('Username already exists. Try a different one.', 'danger')
            return render_template('register.html')

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = sqlite3.connect('meal_app.db')
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
        user = cursor.fetchone()
        conn.close()

        if user:
            session['user_id'] = user[0]
            session['username'] = user[1]
            flash('Login successful!', 'success')
            return redirect(url_for('index'))

        else:
            flash('Invalid credentials. Please try again.', 'danger')
            return render_template('login.html')

    return render_template('login.html')

@app.route('/myplans')
def myplans():
    if 'user_id' not in session:
        flash('Please log in to view your saved meal plans.', 'warning')
        return redirect(url_for('login'))

    user_id = session['user_id']
    conn = sqlite3.connect('meal_app.db')
    cursor = conn.cursor()
    cursor.execute("SELECT date, breakfast, lunch, dinner FROM meal_plans WHERE user_id = ? ORDER BY date DESC", (user_id,))
    plans = cursor.fetchall()
    conn.close()

    return render_template('myplans.html', plans=plans)

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))


if __name__ == '__main__':
    app.run(debug=True)