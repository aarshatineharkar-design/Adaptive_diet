import sqlite3

# Connect to (or create) the database
conn = sqlite3.connect('meal_app.db')

# Create a cursor
cursor = conn.cursor()

# Create users table
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    )
''')

# Create meal_plans table
cursor.execute('''
    CREATE TABLE IF NOT EXISTS meal_plans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        date TEXT,
        breakfast TEXT,
        lunch TEXT,
        dinner TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )
''')

# Save changes and close
conn.commit()
conn.close()
